package com.example.lab02_orderservice.service;

import com.example.lab02_orderservice.model.Product;
import com.example.lab02_orderservice.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    private final ProductRepository repository;
    public ProductService(ProductRepository repository){this.repository=repository;}
    public Product save(Product p){return repository.save(p);}
    public List<Product> findAll(){return repository.findAll();}
    public Optional<Product> findById(Long id){return repository.findById(id);}
    public void deleteById(Long id){repository.deleteById(id);}
}
