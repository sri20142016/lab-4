package com.example.lab02_orderservice;

import com.example.lab02_orderservice.model.User;
import com.example.lab02_orderservice.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner init(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.findByUsername("user").isEmpty()) {
                User u = new User();
                u.setUsername("user");
                // password is 'password' encoded with MD5
                u.setPassword(passwordEncoder.encode("password"));
                u.setRoles("ROLE_USER");
                userRepository.save(u);
            }
        };
    }
}

