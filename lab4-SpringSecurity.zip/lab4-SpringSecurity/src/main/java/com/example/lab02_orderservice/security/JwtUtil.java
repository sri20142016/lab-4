package com.example.lab02_orderservice.security;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class JwtUtil {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    // Create a JWT token (HS512)
    public static String createToken(String subject, Map<String, Object> claims, String secret, long expirationMillis) {
        try {
            Map<String, Object> header = new HashMap<>();
            header.put("alg", "HS512");
            header.put("typ", "JWT");

            long exp = Instant.now().toEpochMilli() + expirationMillis;

            Map<String, Object> payload = new HashMap<>(claims != null ? claims : Map.of());
            payload.put("sub", subject);
            payload.put("exp", exp);

            String headerJson = MAPPER.writeValueAsString(header);
            String payloadJson = MAPPER.writeValueAsString(payload);

            String headerB64 = base64UrlEncode(headerJson.getBytes(StandardCharsets.UTF_8));
            String payloadB64 = base64UrlEncode(payloadJson.getBytes(StandardCharsets.UTF_8));
            String signingInput = headerB64 + "." + payloadB64;

            byte[] signature = hmacSha512(signingInput.getBytes(StandardCharsets.UTF_8), secret.getBytes(StandardCharsets.UTF_8));
            String sigB64 = base64UrlEncode(signature);

            return signingInput + "." + sigB64;
        } catch (Exception e) {
            throw new RuntimeException("Failed to create JWT", e);
        }
    }

    // Parse and verify token. Returns claims map if valid and not expired, otherwise null
    public static Map<String, Object> parseToken(String token, String secret) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length != 3) return null;
            String headerB64 = parts[0];
            String payloadB64 = parts[1];
            String sigB64 = parts[2];

            String signingInput = headerB64 + "." + payloadB64;
            byte[] expectedSig = hmacSha512(signingInput.getBytes(StandardCharsets.UTF_8), secret.getBytes(StandardCharsets.UTF_8));
            byte[] actualSig = base64UrlDecode(sigB64);
            if (actualSig == null) return null;
            if (!MessageDigestisEqual(expectedSig, actualSig)) return null;

            byte[] payloadJson = base64UrlDecode(payloadB64);
            if (payloadJson == null) return null;
            Map<String, Object> claims = MAPPER.readValue(payloadJson, new TypeReference<Map<String, Object>>(){});

            Object expObj = claims.get("exp");
            if (expObj == null) return null;
            long exp;
            if (expObj instanceof Number) {
                exp = ((Number) expObj).longValue();
            } else {
                exp = Long.parseLong(expObj.toString());
            }
            if (Instant.now().toEpochMilli() > exp) return null; // expired

            return claims;
        } catch (Exception e) {
            return null;
        }
    }

    private static String base64UrlEncode(byte[] input) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(input);
    }

    private static byte[] base64UrlDecode(String input) {
        try {
            return Base64.getUrlDecoder().decode(input);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static byte[] hmacSha512(byte[] data, byte[] key) throws NoSuchAlgorithmException, InvalidKeyException {
        Mac mac = Mac.getInstance("HmacSHA512");
        SecretKeySpec keySpec = new SecretKeySpec(key, "HmacSHA512");
        mac.init(keySpec);
        return mac.doFinal(data);
    }

    // Constant-time array comparison
    private static boolean MessageDigestisEqual(byte[] a, byte[] b) {
        if (a == null || b == null) return false;
        if (a.length != b.length) return false;
        int result = 0;
        for (int i = 0; i < a.length; i++) {
            result |= a[i] ^ b[i];
        }
        return result == 0;
    }
}
